
function save_feature_rgb(savefile,gkdes,rgbkdes,lbpkdes,f_ex)

save(savefile,'gkdes','rgbkdes','lbpkdes','f_ex');


