This folder contains functions extracted from the Kernel Descriptor matlab
package. The original code and newer versions are at:

http://www.cs.washington.edu/robotics/projects/kdes/


