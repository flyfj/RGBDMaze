
function save_feature_rgbd(savefile,gkdes,rgbkdes,gkdes_depth,spinkdes,f_ex)

save(savefile,'gkdes','rgbkdes','gkdes_depth','spinkdes','f_ex');


